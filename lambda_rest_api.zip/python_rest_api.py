import requests

def python_rest_api_handler(event, context):
    url = 'http://www.example.com'
    # data = '''{
    #   "query": {
    #     "bool": {
    #       "must": [
    #         {
    #           "text": {
    #             "record.document": "SOME_JOURNAL"
    #           }
    #         },
    #         {
    #           "text": {
    #             "record.articleTitle": "farmers"
    #           }
    #         }
    #       ],
    #       "must_not": [],
    #       "should": []
    #     }
    #   },
    #   "from": 0,
    #   "size": 50,
    #   "sort": [],
    #   "facets": {}
    # }'''
    #response = requests.post(url, data=data)
    response = requests.get(url)
    print(response.text)